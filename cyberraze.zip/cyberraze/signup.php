<?php
// Connect to the MySQL database (Replace 'db_host', 'db_user', 'db_password', and 'db_name' with your database credentials)
$connection = mysqli_connect('localhost', 'root', '', 'form');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Hash the password for security
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insert the user data into the database
    $query = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashed_password')";
    mysqli_query($connection, $query);

    // Redirect to the profile page after successful signup
    header("Location: https://thealamgroup.com/form.com/cyberraze/profile.php");
    exit();
}
?>


<?php
// Connect to the MySQL database (Replace 'db_host', 'db_user', 'db_password', and 'db_name' with your database credentials)
$connection = mysqli_connect('localhost', 'root', '', 'form');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Check if the user exists in the database
    $query = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($connection, $query);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user["password"])) {
        // Start the session and store user data
        session_start();
        $_SESSION["username"] = $user["username"];

        // Redirect to the profile page after successful login
        header("Location: https://thealamgroup.com/form.com/cyberraze/profile.php");
        exit();
    } else {
        // Handle login failure (you can show an error message here)
        echo "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
 <head>
        <meta charset="UTF-8">
      
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style2.css">
        <title>The Website Worker</title>
    </head>
    <body>

   <!-- Add the logout button at the top-right corner of the page -->
    <div class="logout-button">
        <?php if (isset($_SESSION["username"])) : ?>
            <a href="logout.php">Logout</a>
        <?php endif; ?>
    </div>

        
        <div class="container">
            <div class="col-md-3">
        <img src="cropped-cropped-cropped-cr-logo1-01ee.png" alt=""></div>
        <div class="col-md-6">
       <!-- Add the HTML code with PHP tags for form handling -->
<div class="main">
    <input type="checkbox" id="chk" aria-hidden="true">

    <div class="signup">
        <form action="signup.php" method="post">
            <label for="chk" aria-hidden="true">Sign up</label>
            <input type="text" name="username" placeholder="User name" required="">
            <input type="email" name="email" placeholder="Email" required="">
            <input type="password" name="password" placeholder="Password" required="">
            <button type="submit">Sign up</button>
        </form>
    </div>

    <div class="login">
        <form action="signup.php" method="post">
            <label for="chk" aria-hidden="true">Login</label>
            <input type="email" name="email" placeholder="Email" required="">
            <input type="password" name="password" placeholder="Password" required="">
            <button type="submit">Login</button>
        </form>
    </div>
</div>

    </div>
    <div class="col-md-3">
        <h1>we are cyberraze</h1>
    </div>
    </div>
   
    </body>
</html>