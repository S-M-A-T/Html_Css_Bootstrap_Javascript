<?php
// Connect to the MySQL database (Replace 'db_host', 'db_user', 'db_password', and 'db_name' with your database credentials)
$connection = mysqli_connect('db_host', 'db_user', 'db_password', 'db_name');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Check if the user exists in the database
    $query = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($connection, $query);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user["password"])) {
        // Start the session and store user data
        session_start();
        $_SESSION["username"] = $user["username"];

        // Redirect to the profile page after successful login
        header("Location: profile.php");
        exit();
    } else {
        // Handle login failure (you can show an error message here)
        echo "Invalid email or password.";
    }
}
?>
