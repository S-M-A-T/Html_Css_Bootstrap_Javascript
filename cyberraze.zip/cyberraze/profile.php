<?php
// Start the session to access stored user data
session_start();


?>
<?php


// Unset all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to the login page or any other page after logout
header("Location: localhost/index.html");
exit();
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
      
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style3.css">
        <title>The Website Worker</title>  
        <style>
            /* Add CSS for the logout button */
.logout-button {
    position: absolute;
    top: 10px;
    right: 10px;
}

.logout-button a {
    display: block;
    padding: 8px 16px;
    background-color: #f44336;
    color: #ffffff;
    text-decoration: none;
    border-radius: 4px;
}

.logout-button a:hover {
    background-color: #d32f2f;
}

        </style>
    </head>
<body>

       <!-- Add the logout button at the top-right corner of the page -->
    
    <div class="container">
     <!-- <h1 id="username">Welcome, <?php echo $_SESSION["username"]; ?></h1> -->
        <div class="avatar-upload">
            <div class="avatar-edit">
                <input type='file' id="imageUpload" accept=".png, .jpg, .jpeg" />
                <label for="imageUpload"></label>
            </div>
            <div class="avatar-preview">
                <div id="imagePreview" class="profile_img" style="background-image: url(cropped-cropped-cropped-cr-logo1-01ee.png);">
                </div>
            </div>
        </div>
    </div>
    <div class="container">  
 <form id="contact" action="profile.php" method="post">
       
       
             <fieldset>
        <input placeholder="Your name" type="text" name="name" tabindex="1" required autofocus>
    </fieldset>
    <fieldset>
        <input placeholder="Arrival time(11.30)" type="number" name="arrival_time" tabindex="2" required>
    </fieldset>
    <fieldset>
        <input placeholder="when did you leave(8.30)" type="number" name="leave_time" tabindex="3" required>
    </fieldset>
    <fieldset>
        <input placeholder="How much work did you do today?" type="text" name="work_done" tabindex="3" required>
    </fieldset>
    <fieldset>
        <textarea placeholder="Any complain (Employee name:complain)" name="complain" tabindex="5" required></textarea>
    </fieldset>
    <fieldset>
        <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Submit</button>
    </fieldset>
</form>
       
        
      </div>
    <script>function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#imagePreview').css('background-image', 'url('+e.target.result +')');
                $('#imagePreview').hide();
                $('#imagePreview').fadeIn(650);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imageUpload").change(function() {
        readURL(this);
    });</script>
</body>
</html>